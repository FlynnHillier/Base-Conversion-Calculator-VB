﻿Public Class Form1

    'made by Flynn Hillier

    Dim toconvert As String = "" 'will be 'dec' 'bin' or 'hex' specifies what to convert from
    Dim converto As String = "" 'will be 'dec' 'bin' or 'hex' specifies what to convert into
    Dim changebuttoncheck1 As String
    Dim changebuttoncheck2 As String



    'will make 'convert from' buttons look pressed. will clear both text boxes if different button is clicked from one previously selected
    Sub buttonclicked1(button)
        ConvertFromTBox.ReadOnly = False
        Decimal1.BorderStyle = BorderStyle.None
        Hexadecimal1.BorderStyle = BorderStyle.None
        Binary1.BorderStyle = BorderStyle.None
        If button = "dec" Then
            Decimal1.BorderStyle = BorderStyle.Fixed3D

        ElseIf button = "hex" Then
            Hexadecimal1.BorderStyle = BorderStyle.Fixed3D

        ElseIf button = "bin" Then
            Binary1.BorderStyle = BorderStyle.Fixed3D

        Else
            MessageBox.Show("Error selecting button")
        End If
        If button <> changebuttoncheck1 Then
            ConvertFromTBox.Clear()
            ConvertedTBox.Clear()
        End If

        toconvert = button
        changebuttoncheck1 = button

    End Sub


    'will make 'convert to' buttons look pressed. will also carry out 'process()' if a button different to the one previously selected is clicked.
    Sub buttonclicked2(button)
        Decimal2.BorderStyle = BorderStyle.None
        Hexadecimal2.BorderStyle = BorderStyle.None
        Binary2.BorderStyle = BorderStyle.None
        If button = "dec" Then
            Decimal2.BorderStyle = BorderStyle.Fixed3D

        ElseIf button = "hex" Then
            Hexadecimal2.BorderStyle = BorderStyle.Fixed3D

        ElseIf button = "bin" Then
            Binary2.BorderStyle = BorderStyle.Fixed3D

        Else
            MessageBox.Show("Error selecting button")
        End If
        converto = button
        If button <> changebuttoncheck2 Then
            ConvertedTBox.Clear()
            process()
        End If

        changebuttoncheck2 = button

    End Sub



    'if 'convert from' buttons are clicked
    Private Sub Decimal1_Click(sender As Object, e As EventArgs) Handles Decimal1.Click
        buttonclicked1("dec")
    End Sub

    Private Sub Binary1_Click(sender As Object, e As EventArgs) Handles Binary1.Click
        buttonclicked1("bin")
    End Sub

    Private Sub Hexadecimal1_Click(sender As Object, e As EventArgs) Handles Hexadecimal1.Click
        buttonclicked1("hex")
    End Sub


    'if 'convert to' buttons are clicked
    Private Sub Decimal2_Click(sender As Object, e As EventArgs) Handles Decimal2.Click
        buttonclicked2("dec")
    End Sub

    Private Sub Binary2_Click(sender As Object, e As EventArgs) Handles Binary2.Click
        buttonclicked2("bin")
    End Sub

    Private Sub Hexadecimal2_Click(sender As Object, e As EventArgs) Handles Hexadecimal2.Click
        buttonclicked2("hex")
    End Sub




    'convertfromtbox
    Private Sub convertfromtbox_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ConvertFromTBox.KeyPress

        'validates last keypress Is decimal compatiable will deny it if Not
        If toconvert = "dec" Then
            If Asc(e.KeyChar) <> 8 Then
                If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                End If
            End If
        End If


        'validates last keypress is binary compatiable will deny it if not
        If toconvert = "bin" Then
            If Asc(e.KeyChar) <> 8 Then
                If e.KeyChar <> "0" And e.KeyChar <> "1" Then
                    e.Handled = True
                End If
            End If
        End If


        'validates last keypress is hex compatiable will deny it if not
        If toconvert = "hex" Then
            If Asc(e.KeyChar) <> 8 Then
                If InStr(1, "ABCDEFabcdef", CStr(e.KeyChar)) <> 0 Then
                    e.KeyChar = CStr(e.KeyChar).ToUpper
                    e.Handled = False
                ElseIf Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                End If
            End If
        End If


    End Sub

    'carries out process() when user inputs into textbox
    Private Sub ConvertFromTBox_TextChanged(sender As Object, e As EventArgs) Handles ConvertFromTBox.TextChanged
        process()
    End Sub


    'carries out processes of converting 'convert to' text box into the selected number type and displaying it in the'converted' text box   uses functions below for the maths
    Sub process()
        If toconvert = "dec" Then
            Dim x As Integer = 0
            Integer.TryParse(ConvertFromTBox.Text, x)
            If converto = "hex" Then
                ConvertedTBox.Text = dentohexprocess(x)
            ElseIf converto = "bin" Then
                ConvertedTBox.Text = DenToBinprocess(x)
            ElseIf converto = "dec" Then
                ConvertedTBox.Text = x
            End If
        ElseIf toconvert = "bin" Then
            If converto = "hex" Then
                ConvertedTBox.Text = dentohexprocess(bintodenprocess(CStr(ConvertFromTBox.Text)))
            ElseIf converto = "dec" Then
                ConvertedTBox.Text = bintodenprocess(CStr(ConvertFromTBox.Text))
            ElseIf converto = "bin" Then
                ConvertedTBox.Text = ConvertFromTBox.Text
            End If
        ElseIf toconvert = "hex" Then
            If converto = "dec" Then
                ConvertedTBox.Text = hextodenprocess(CStr(ConvertFromTBox.Text))
            ElseIf converto = "bin" Then
                ConvertedTBox.Text = DenToBinprocess(hextodenprocess(CStr(ConvertFromTBox.Text)))
            ElseIf converto = "hex" Then
                ConvertedTBox.Text = ConvertFromTBox.Text
            End If
        End If
    End Sub



    'converts 'denary' to hexadecimal string
    Public Function dentohexprocess(denary) As String
        Dim uout As String = ""
        Dim x As Integer
        While denary > 0
            x = denary Mod 16
            denary = denary \ 16

            If x < 10 Then
                uout += CStr(x)
            ElseIf x = 10 Then
                uout += "A"
            ElseIf x = 11 Then
                uout += "B"
            ElseIf x = 12 Then
                uout += "C"
            ElseIf x = 13 Then
                uout += "D"
            ElseIf x = 14 Then
                uout += "E"
            ElseIf x = 15 Then
                uout += "F"
            End If

        End While

        Dim out As String = ""
        Dim y As Integer
        For i = 1 To uout.Length
            y += 1
            out += uout(uout.Length - y)
        Next

        Return out

    End Function




    'converts denary number to binary returns binary value
    Public Function DenToBinprocess(inp)
        Dim den As Integer = inp
        Dim bin As String = ""

        While den > 0
            bin = bin.Insert(0, CStr(den Mod 2))
            den = den \ 2
        End While

        Return bin
    End Function



    'returns the denary equivalent to 'binary'
    Public Function bintodenprocess(binary) As Double
        Dim value As Integer = 1
        Dim out As Integer

        For i = 1 To binary.length
            If binary(binary.length - (i)) = "1" Then
                out += value
            End If
            value *= 2
        Next
        Return out

    End Function



    'converts hexadecimal to denary
    Public Function hextodenprocess(hex)
        Dim inti As Integer
        Dim out As Integer

        For i = 0 To hex.length - 1
            If Integer.TryParse(hex(hex.length - (i + 1)), inti) Then
                out += inti * (16 ^ i)
            ElseIf hex(hex.length - (i + 1)) = "A" Then
                out += 10 * (16 ^ i)
            ElseIf hex(hex.length - (i + 1)) = "B" Then
                out += 11 * (16 ^ i)
            ElseIf hex(hex.length - (i + 1)) = "C" Then
                out += 12 * (16 ^ i)
            ElseIf hex(hex.length - (i + 1)) = "D" Then
                out += 13 * (16 ^ i)
            ElseIf hex(hex.length - (i + 1)) = "E" Then
                out += 14 * (16 ^ i)
            ElseIf hex(hex.length - (i + 1)) = "F" Then
                out += 15 * (16 ^ i)
            ElseIf hex(hex.length - (i + 1)) = "0" Then
                out += 0
            End If

        Next

        Return out
    End Function

    'Made by flynn Hillier
End Class

