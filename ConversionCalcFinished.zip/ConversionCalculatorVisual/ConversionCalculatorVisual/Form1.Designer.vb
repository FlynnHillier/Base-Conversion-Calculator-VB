﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.ConvertFromTBox = New System.Windows.Forms.TextBox()
        Me.ConvertedTBox = New System.Windows.Forms.TextBox()
        Me.Decimal1 = New System.Windows.Forms.Label()
        Me.Binary1 = New System.Windows.Forms.Label()
        Me.Hexadecimal1 = New System.Windows.Forms.Label()
        Me.Hexadecimal2 = New System.Windows.Forms.Label()
        Me.Binary2 = New System.Windows.Forms.Label()
        Me.Decimal2 = New System.Windows.Forms.Label()
        Me.LabelConvertFrom = New System.Windows.Forms.Label()
        Me.LabelConvertTo = New System.Windows.Forms.Label()
        Me.HeaderLabel = New System.Windows.Forms.Label()
        Me.HeaderLabel2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'ConvertFromTBox
        '
        Me.ConvertFromTBox.Location = New System.Drawing.Point(50, 363)
        Me.ConvertFromTBox.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.ConvertFromTBox.Name = "ConvertFromTBox"
        Me.ConvertFromTBox.ReadOnly = True
        Me.ConvertFromTBox.Size = New System.Drawing.Size(212, 20)
        Me.ConvertFromTBox.TabIndex = 0
        '
        'ConvertedTBox
        '
        Me.ConvertedTBox.Location = New System.Drawing.Point(50, 438)
        Me.ConvertedTBox.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.ConvertedTBox.Name = "ConvertedTBox"
        Me.ConvertedTBox.ReadOnly = True
        Me.ConvertedTBox.Size = New System.Drawing.Size(212, 20)
        Me.ConvertedTBox.TabIndex = 1
        '
        'Decimal1
        '
        Me.Decimal1.AutoSize = True
        Me.Decimal1.BackColor = System.Drawing.Color.LightGray
        Me.Decimal1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Decimal1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Decimal1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Decimal1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Decimal1.Location = New System.Drawing.Point(276, 362)
        Me.Decimal1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Decimal1.MinimumSize = New System.Drawing.Size(44, 21)
        Me.Decimal1.Name = "Decimal1"
        Me.Decimal1.Size = New System.Drawing.Size(55, 21)
        Me.Decimal1.TabIndex = 5
        Me.Decimal1.Text = "Decimal"
        Me.Decimal1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Binary1
        '
        Me.Binary1.AutoSize = True
        Me.Binary1.BackColor = System.Drawing.Color.LightGray
        Me.Binary1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Binary1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Binary1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Binary1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Binary1.Location = New System.Drawing.Point(335, 362)
        Me.Binary1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Binary1.MinimumSize = New System.Drawing.Size(44, 21)
        Me.Binary1.Name = "Binary1"
        Me.Binary1.Size = New System.Drawing.Size(45, 21)
        Me.Binary1.TabIndex = 6
        Me.Binary1.Text = "Binary"
        Me.Binary1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Hexadecimal1
        '
        Me.Hexadecimal1.AutoSize = True
        Me.Hexadecimal1.BackColor = System.Drawing.Color.LightGray
        Me.Hexadecimal1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Hexadecimal1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Hexadecimal1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Hexadecimal1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Hexadecimal1.Location = New System.Drawing.Point(384, 362)
        Me.Hexadecimal1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Hexadecimal1.MinimumSize = New System.Drawing.Size(44, 21)
        Me.Hexadecimal1.Name = "Hexadecimal1"
        Me.Hexadecimal1.Size = New System.Drawing.Size(83, 21)
        Me.Hexadecimal1.TabIndex = 7
        Me.Hexadecimal1.Text = "Hexadecimal"
        Me.Hexadecimal1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Hexadecimal2
        '
        Me.Hexadecimal2.AutoSize = True
        Me.Hexadecimal2.BackColor = System.Drawing.Color.LightGray
        Me.Hexadecimal2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Hexadecimal2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Hexadecimal2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Hexadecimal2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Hexadecimal2.Location = New System.Drawing.Point(384, 437)
        Me.Hexadecimal2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Hexadecimal2.MinimumSize = New System.Drawing.Size(44, 21)
        Me.Hexadecimal2.Name = "Hexadecimal2"
        Me.Hexadecimal2.Size = New System.Drawing.Size(83, 21)
        Me.Hexadecimal2.TabIndex = 10
        Me.Hexadecimal2.Text = "Hexadecimal"
        Me.Hexadecimal2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Binary2
        '
        Me.Binary2.AutoSize = True
        Me.Binary2.BackColor = System.Drawing.Color.LightGray
        Me.Binary2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Binary2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Binary2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Binary2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Binary2.Location = New System.Drawing.Point(335, 437)
        Me.Binary2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Binary2.MinimumSize = New System.Drawing.Size(44, 21)
        Me.Binary2.Name = "Binary2"
        Me.Binary2.Size = New System.Drawing.Size(45, 21)
        Me.Binary2.TabIndex = 9
        Me.Binary2.Text = "Binary"
        Me.Binary2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Decimal2
        '
        Me.Decimal2.AutoSize = True
        Me.Decimal2.BackColor = System.Drawing.Color.LightGray
        Me.Decimal2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Decimal2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Decimal2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Decimal2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Decimal2.Location = New System.Drawing.Point(276, 437)
        Me.Decimal2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Decimal2.MinimumSize = New System.Drawing.Size(44, 21)
        Me.Decimal2.Name = "Decimal2"
        Me.Decimal2.Size = New System.Drawing.Size(55, 21)
        Me.Decimal2.TabIndex = 8
        Me.Decimal2.Text = "Decimal"
        Me.Decimal2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelConvertFrom
        '
        Me.LabelConvertFrom.AutoSize = True
        Me.LabelConvertFrom.Font = New System.Drawing.Font("Arial", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelConvertFrom.Location = New System.Drawing.Point(323, 338)
        Me.LabelConvertFrom.Name = "LabelConvertFrom"
        Me.LabelConvertFrom.Size = New System.Drawing.Size(83, 14)
        Me.LabelConvertFrom.TabIndex = 11
        Me.LabelConvertFrom.Text = "Convert From"
        Me.LabelConvertFrom.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelConvertTo
        '
        Me.LabelConvertTo.AutoSize = True
        Me.LabelConvertTo.Font = New System.Drawing.Font("Arial", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelConvertTo.Location = New System.Drawing.Point(323, 411)
        Me.LabelConvertTo.Name = "LabelConvertTo"
        Me.LabelConvertTo.Size = New System.Drawing.Size(67, 14)
        Me.LabelConvertTo.TabIndex = 12
        Me.LabelConvertTo.Text = "Convert To"
        Me.LabelConvertTo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'HeaderLabel
        '
        Me.HeaderLabel.AutoSize = True
        Me.HeaderLabel.Font = New System.Drawing.Font("Lucida Sans Unicode", 32.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HeaderLabel.Location = New System.Drawing.Point(113, 9)
        Me.HeaderLabel.Name = "HeaderLabel"
        Me.HeaderLabel.Size = New System.Drawing.Size(267, 53)
        Me.HeaderLabel.TabIndex = 13
        Me.HeaderLabel.Text = "Conversion"
        '
        'HeaderLabel2
        '
        Me.HeaderLabel2.AutoSize = True
        Me.HeaderLabel2.Font = New System.Drawing.Font("Lucida Sans Unicode", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HeaderLabel2.Location = New System.Drawing.Point(138, 62)
        Me.HeaderLabel2.Name = "HeaderLabel2"
        Me.HeaderLabel2.Size = New System.Drawing.Size(212, 45)
        Me.HeaderLabel2.TabIndex = 14
        Me.HeaderLabel2.Text = "Calculator"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(506, 484)
        Me.Controls.Add(Me.HeaderLabel2)
        Me.Controls.Add(Me.HeaderLabel)
        Me.Controls.Add(Me.LabelConvertTo)
        Me.Controls.Add(Me.LabelConvertFrom)
        Me.Controls.Add(Me.Hexadecimal2)
        Me.Controls.Add(Me.Binary2)
        Me.Controls.Add(Me.Decimal2)
        Me.Controls.Add(Me.Hexadecimal1)
        Me.Controls.Add(Me.Binary1)
        Me.Controls.Add(Me.Decimal1)
        Me.Controls.Add(Me.ConvertedTBox)
        Me.Controls.Add(Me.ConvertFromTBox)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "Flynn's Conversion Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ConvertFromTBox As TextBox
    Friend WithEvents ConvertedTBox As TextBox
    Friend WithEvents Decimal1 As Label
    Friend WithEvents Binary1 As Label
    Friend WithEvents Hexadecimal1 As Label
    Friend WithEvents Hexadecimal2 As Label
    Friend WithEvents Binary2 As Label
    Friend WithEvents Decimal2 As Label
    Friend WithEvents LabelConvertFrom As Label
    Friend WithEvents LabelConvertTo As Label
    Friend WithEvents HeaderLabel As Label
    Friend WithEvents HeaderLabel2 As Label
End Class
